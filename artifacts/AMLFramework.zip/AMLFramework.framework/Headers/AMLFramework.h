//
//  AMLFramework.h
//  AMLFramework
//
//  Created by Santosh on 31/05/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for AMLFramework.
FOUNDATION_EXPORT double AMLFrameworkVersionNumber;

//! Project version string for AMLFramework.
FOUNDATION_EXPORT const unsigned char AMLFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AMLFramework/PublicHeader.h>


